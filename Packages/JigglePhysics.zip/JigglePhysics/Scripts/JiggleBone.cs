namespace JigglePhysics
{
    // Uses Verlet to resolve constraints easily 
    public class JiggleBone
    {
        public int JiggleParentIndex;
        public int childIndex;
        public int boneIndex;
    }
}