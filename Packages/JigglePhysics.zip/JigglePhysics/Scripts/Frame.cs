﻿using UnityEngine;
namespace JigglePhysics
{
    public struct Frame
    {
        public Vector3 position;
        public double time;
    }
}